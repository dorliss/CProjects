with
    visit as (
    select piz.name as pizzeria_name
    from pizzeria piz
    join person_visits pv on piz.id = pv.pizzeria_id
    join person pers on pv.person_id = pers.id
    where pers.name = 'Andrey'
),
 orders as (
     select piz.name as pizzeria_name
     from pizzeria piz
     join menu mn on piz.id = mn.pizzeria_id
     join person_order po on mn.id = po.menu_id
     join person pers on po.person_id = pers.id
     where pers.name = 'Andrey'
 )

select * from visit
except
select * from orders
order by pizzeria_name