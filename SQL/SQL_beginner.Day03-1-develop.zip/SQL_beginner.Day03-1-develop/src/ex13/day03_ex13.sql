delete from person_order
where order_date = '2022-02-25';

delete from menu
where pizza_name = 'greek pizza';