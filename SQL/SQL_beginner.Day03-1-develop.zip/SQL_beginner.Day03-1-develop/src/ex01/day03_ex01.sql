select id as menu_id
from menu mn
where not exists (select id from person_order po where po.menu_id = mn.id)
order by menu_id