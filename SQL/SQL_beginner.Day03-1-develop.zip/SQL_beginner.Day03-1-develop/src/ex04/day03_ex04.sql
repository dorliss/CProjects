with
    male as (
        select piz.name as pizzeria_name
        from person_order po
        join menu mn on po.menu_id = mn.id
        join pizzeria piz on mn.pizzeria_id = piz.id
        join person pers on po.person_id = pers.id
        where gender = 'male'
    ),

    female as (
        select piz.name as pizzeria_name
        from person_order po
        join menu mn on po.menu_id = mn.id
        join pizzeria piz on mn.pizzeria_id = piz.id
        join person pers on po.person_id = pers.id
        where gender = 'female'
    ),

    male_only as (
        select * from male
        except
        select * from female
    ),

    female_only as (
        select * from female
        except
        select * from male
    )

select * from male_only
union
select * from female_only
order by pizzeria_name