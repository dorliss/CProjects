select mn.pizza_name, mn.price, pz.name as pizzeria_name, pv.visit_date
from person_visits pv
join person pers
  on pers.id = pv.person_id
join menu mn
  on pv.pizzeria_id = mn.pizzeria_id
join pizzeria pz
  on pv.pizzeria_id = pz.id
where pers.name = 'Kate' and mn.price>=800 and mn.price<=1000
order by mn.pizza_name,mn.price,pizzeria_name