insert into menu values (19,2,'greek pizza', 800);

-- select * from menu