with tabl as (
    select mn.id, mn.pizza_name, piz.name, piz.id as piz_id, mn.price
    from menu mn
    join pizzeria piz on mn.pizzeria_id = piz.id
)

select tabl1.pizza_name, tabl1.name as pizzeria_name_1, tabl2.name as pizzeria_name_2, tabl1.price
from tabl tabl1
left join tabl tabl2 on tabl1.pizza_name = tabl2.pizza_name and tabl1.price = tabl2.price and tabl1.name != tabl2.name
where tabl2.name is not null and tabl1.piz_id > tabl2.piz_id
order by pizza_name;