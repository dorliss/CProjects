with not_order as (
    select id as menu_id
    from menu mn
    where not exists (select id from person_order po where po.menu_id = mn.id)
    order by id
)

select mn.pizza_name, mn.price, pz.name as pizzeria_name
from not_order no
join menu mn on no.menu_id = mn.id
join pizzeria pz on mn.pizzeria_id = pz.id
order by mn.pizza_name,mn.price