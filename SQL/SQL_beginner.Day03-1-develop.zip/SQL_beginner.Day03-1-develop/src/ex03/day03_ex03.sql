with
    male as (
        select piz.name as pizzeria_name
        from person_visits pv
        join pizzeria piz on pv.pizzeria_id = piz.id
        join person pers on pv.person_id = pers.id
        where gender = 'male'
    ),

    female as (
        select piz.name as pizzeria_name
        from person_visits pv
        join pizzeria piz on pv.pizzeria_id = piz.id
        join person pers on pv.person_id = pers.id
        where gender = 'female'
    ),

    male_only as (
        select * from male
        except all
        select * from female
    ),

    female_only as (
        select * from female
        except all
        select * from male
    )

select * from male_only
union all
select * from female_only
order by pizzeria_name