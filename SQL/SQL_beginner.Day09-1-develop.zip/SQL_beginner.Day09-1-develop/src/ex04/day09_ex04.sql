create function fnc_persons_female()
returns table 
(
	id bigint,
  name varchar,
  age integer,
  gender varchar,
  address varchar
) as $$
select id, name, age, gender, address from person where gender = 'female';
$$ LANGUAGE SQL;

create function fnc_persons_male()
returns table 
(
	id bigint,
  name varchar,
  age integer,
  gender varchar,
  address varchar
) as $$
select id, name, age, gender, address from person where gender = 'male';
$$ LANGUAGE SQL;

SELECT *
FROM fnc_persons_male();

SELECT *
FROM fnc_persons_female();