create view v_price_with_discount as
select pers.name, mn.pizza_name, mn.price, 
round(mn.price - mn.price*0.1) as discount_price
from person_order po
join person pers on po.person_id = pers.id
join menu mn on po.menu_id = mn.id
order by pers.name, mn.pizza_name

-- select * from v_price_with_discount