drop materialized view if exists mv_dmitriy_visits_and_eats;

drop view if exists v_generated_dates;
drop view if exists v_persons_female;
drop view if exists v_persons_male;
drop view if exists v_price_with_discount;
drop view if exists v_symmetric_union;
