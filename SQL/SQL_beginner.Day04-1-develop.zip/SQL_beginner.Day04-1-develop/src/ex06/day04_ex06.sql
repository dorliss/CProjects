create materialized view mv_dmitriy_visits_and_eats as
select piz.name as pizzeria_name
from person pers
join person_visits pv on pers.id = pv.person_id
join pizzeria piz on pv.pizzeria_id = piz.id
join menu mn on piz.id = mn.pizzeria_id
where pers.name = 'Dmitriy' and pv.visit_date = '2022-01-08' and mn.price < 800
order by pizzeria_name;