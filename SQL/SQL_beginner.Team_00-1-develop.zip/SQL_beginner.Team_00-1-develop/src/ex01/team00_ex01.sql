with recursive praph as (
  select point1 as path,
    point1, point2, cost
  from tours
  where point1 = 'a'
  union
  select concat(praph.path, ',', tours.point1) AS path,
    tours.point1, tours.point2,
    praph.cost + tours.cost
  from praph
    join tours
    ON praph.point2 = tours.point1
  where path NOT LIKE concat('%', tours.point1, '%')
  ), ways as (
  select cost as total_cost,
    concat('{', path, ',', point2, '}') as tour
  from praph
  where length(path) = 7 and point2 = 'a'
)
select *
from ways
where total_cost = (
  select min(total_cost)
  from ways
)
union all
select *
from ways
where total_cost = (
  select max(total_cost)
  from ways
)
order by total_cost, tour;