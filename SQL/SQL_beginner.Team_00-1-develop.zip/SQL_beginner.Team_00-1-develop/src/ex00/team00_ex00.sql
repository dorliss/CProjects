CREATE TABLE IF NOT EXISTS tours (
  point1 VARCHAR,  
  point2 VARCHAR,  
  cost INTEGER     
);

INSERT INTO tours VALUES ('a', 'b', 10);
INSERT INTO tours VALUES ('a', 'c', 15);
INSERT INTO tours VALUES ('a', 'd', 20);
INSERT INTO tours VALUES ('b', 'a', 10);
INSERT INTO tours VALUES ('b', 'c', 35);
INSERT INTO tours VALUES ('b', 'd', 25);
INSERT INTO tours VALUES ('c', 'a', 15);
INSERT INTO tours VALUES ('c', 'b', 35);
INSERT INTO tours VALUES ('c', 'd', 30);
INSERT INTO tours VALUES ('d', 'a', 20);
INSERT INTO tours VALUES ('d', 'b', 25);
INSERT INTO tours VALUES ('d', 'c', 30);

-- Рекурсивное общее табличное выражение для построения маршрутов из точки 'a'
WITH RECURSIVE graph AS (
  -- Начальный выбор: маршруты, начинающиеся с точки 'a'
  SELECT point1 AS path, point1, point2, cost
  FROM tours 
  WHERE point1 = 'a'
  
  UNION
  
  -- Рекурсивное объединение для добавления новых точек в маршрут
  SELECT CONCAT(graph.path, ',', tours.point1) AS path,
         tours.point1,
         tours.point2,
         graph.cost + tours.cost
  FROM graph
    JOIN tours 
    ON graph.point2 = tours.point1
  WHERE path NOT LIKE CONCAT('%', tours.point1, '%')
),

-- Фильтрация маршрутов
routes AS (
  SELECT cost AS total_cost,
         CONCAT('{', path, ',', point2, '}') AS tour
  FROM graph
  WHERE LENGTH(path) = 7 AND point2 = 'a'
)

-- Выбор маршрутов с минимальной стоимостью
SELECT *
FROM routes
WHERE total_cost = (
  SELECT MIN(total_cost)
  FROM routes
)
ORDER BY total_cost, tour; -- Упорядочить по стоимости и представлению маршрута