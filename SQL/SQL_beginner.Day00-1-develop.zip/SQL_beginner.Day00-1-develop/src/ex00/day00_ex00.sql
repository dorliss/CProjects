select name, age
from person
where address = 'Kazan' and gender = 'female'
order by name;