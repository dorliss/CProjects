-- 1 variant
select name, rating
from pizzeria
where rating >= 3.5 AND rating <= 5
order by rating;

-- 2 variant
select name, rating
from pizzeria
where rating between 3.5 and 5
order by rating;