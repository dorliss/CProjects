-- session #1
BEGIN TRANSACTION;
SELECT * FROM pizzeria WHERE name = 'Pizza Hut';
UPDATE pizzeria SET rating = 4 WHERE name = 'Pizza Hut';
COMMIT;
SELECT * FROM pizzeria WHERE name = 'Pizza Hut';

-- session #2
BEGIN TRANSACTION;
SELECT * FROM pizzeria WHERE name = 'Pizza Hut';

-- will not work until the transaction for 1 session is completed via COMMIT
UPDATE pizzeria SET rating = 3.6 WHERE name = 'Pizza Hut';
COMMIT;
SELECT * FROM pizzeria WHERE name = 'Pizza Hut';