comment on table person_discounts is 'Discounts for person';
comment on column person_discounts.id is 'Id field';
comment on column person_discounts.person_id is 'Person id field';
comment on column person_discounts.pizzeria_id is 'Pizzeria id field';
comment on column person_discounts.discount is 'Person discount (percentage) in a pizzeria';