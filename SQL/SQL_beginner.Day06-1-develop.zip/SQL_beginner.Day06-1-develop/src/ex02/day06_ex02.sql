select pers.name,
       mn.pizza_name,
       mn.price,
       (mn.price - mn.price * (pd.discount / 100)) as discount_price,
       pizz.name                                    as pizzeria_name
from person_order po
         inner join menu mn on mn.id = po.menu_id
         inner join person_discounts pd on pd.person_id = po.person_id and pd.pizzeria_id = mn.pizzeria_id
         inner join person pers on pers.id = po.person_id
         inner join pizzeria pizz on pizz.id = mn.pizzeria_id
order by pers.name, mn.pizza_name;
