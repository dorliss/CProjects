select pers.address, pizz.name, count(*) as count_of_orders
from person_order po
inner join menu mn on mn.id = po.menu_id
inner join pizzeria pizz on mn.pizzeria_id = pizz.id
inner join person pers on pers.id = po.person_id
GROUP BY pers.address, pizz.name
ORDER BY pers.address, pizz.name;