select distinct name
from person pe
inner join person_order po on pe.id = po.person_id
order by name;