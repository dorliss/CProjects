select pers.name, count(*) as count_of_visits
from person_visits pv
inner join person pers on pers.id = pv.person_id
group by pers.name
having count(*) > 3;