select pizz.name, count(pizz.name) as count_of_orders,
round(avg(mn.price), 2) as average_price,
max(mn.price) as max_price,
min(mn.price) as min_price
from person_order po
inner join menu mn on mn.id = po.menu_id
inner join pizzeria pizz on pizz.id = mn.pizzeria_id
GROUP BY pizz.name
ORDER BY pizz.name;