select coalesce(po.name, pv.name) as name,
       coalesce(po.count, 0) + coalesce(pv.count, 0) as total_count
from (select pizz.name, count(*) as count
      from person_order po
               inner join menu mn on mn.id = po.menu_id
               inner join pizzeria pizz on pizz.id = mn.pizzeria_id
      group by pizz.name) as po
         full outer join (select pizz.name, count(*) as count
                          from person_visits pv
                                   inner join pizzeria pizz on pizz.id = pv.pizzeria_id
                          group by pizz.name) as pv on po.name = pv.name
order by total_count desc, name;