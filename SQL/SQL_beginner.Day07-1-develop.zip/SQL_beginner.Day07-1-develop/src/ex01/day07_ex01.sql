select name, count(*) as count_of_visits
from person_visits pv
inner join person pers on pers.id = pv.person_id
group by name
order by count_of_visits desc, name
limit 4;