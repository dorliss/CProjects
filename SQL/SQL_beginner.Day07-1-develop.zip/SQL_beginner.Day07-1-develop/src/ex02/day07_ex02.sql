(select name, count(*) as count, 'order' as action_type
 from person_order po
 inner join menu mn on mn.id = po.menu_id
 inner join pizzeria pizz on pizz.id = mn.pizzeria_id
 group by name
 order by count desc
 limit 3)
union
(select name, count(*) as count, 'visit' as action_type
 from person_visits pv
 inner join pizzeria pizz on pizz.id = pv.pizzeria_id
 group by name
 order by count desc
 limit 3)
order by action_type, count desc;