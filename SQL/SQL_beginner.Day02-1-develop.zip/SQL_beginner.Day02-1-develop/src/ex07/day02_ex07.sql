select piz.name as pizzeria_name
from person_visits pv
join person pers on pers.id = pv.person_id
join pizzeria piz on pv.pizzeria_id = piz.id
join menu mn on piz.id = mn.pizzeria_id
where pers.name = 'Dmitriy' and visit_date = '2022-01-08' and price < 800