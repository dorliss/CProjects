select pers.name
from person pers
join person_order po on pers.id = po.person_id
join menu mn on po.menu_id = mn.id
where pers.gender = 'male' and (pers.address = 'Moscow' or pers.address = 'Samara')
  and (mn.pizza_name = 'mushroom pizza' or mn.pizza_name = 'pepperoni pizza')
order by name desc
