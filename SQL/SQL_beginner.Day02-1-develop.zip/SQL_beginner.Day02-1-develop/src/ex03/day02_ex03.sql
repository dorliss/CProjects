with dates as (
    select missing_date::date
    from generate_series('2022-01-01'::date, '2022-01-10', '1 day') as missing_date
)

select missing_date
from dates
         left join (select * from person_visits pv
                    where (pv.person_id = '1' or pv.person_id = '2')
                      and (pv.visit_date>='2022-01-01' and pv.visit_date<='2022-01-10')
) cond on (missing_date = cond.visit_date)
where visit_date is null
order by missing_date asc;