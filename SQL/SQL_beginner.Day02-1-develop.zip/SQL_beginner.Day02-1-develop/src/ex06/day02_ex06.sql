select mn.pizza_name, piz.name as pizzeria_name
from menu mn
join pizzeria piz
    on mn.pizzeria_id = piz.id
join person_order po
    on mn.id = po.menu_id
join person pers
    on po.person_id = pers.id
where pers.name = 'Denis' or pers.name = 'Anna'
order by pizza_name, pizzeria_name