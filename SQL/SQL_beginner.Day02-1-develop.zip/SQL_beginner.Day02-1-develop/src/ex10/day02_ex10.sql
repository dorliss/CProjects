select pers1.name as person_name1, pers2.name as person_name2, pers2.address as common_address
from person pers1, person pers2
where pers1.address = pers2.address and pers1.id > pers2.id
order by person_name1,person_name2,common_address asc