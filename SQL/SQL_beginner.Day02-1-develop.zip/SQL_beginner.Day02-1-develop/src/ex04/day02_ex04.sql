select mn.pizza_name, piz.name as pizzeria_name, mn.price
from pizzeria piz
inner join menu mn on piz.id = mn.pizzeria_id
where mn.pizza_name = 'mushroom pizza' or mn.pizza_name = 'pepperoni pizza'
order by pizza_name, pizzeria_name