with female as (
select pers.name, mn.pizza_name
from person pers
join person_order po on pers.id = po.person_id
join menu mn on po.menu_id = mn.id
where pers.gender = 'female'
)

select name
from female
where pizza_name = 'pepperoni pizza'
intersect
select name
from female
where pizza_name = 'cheese pizza'
order by name asc