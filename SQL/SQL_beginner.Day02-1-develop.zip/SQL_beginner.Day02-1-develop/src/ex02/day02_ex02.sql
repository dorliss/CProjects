select coalesce(per.name, '-') as person_name,
       pv.visit_date           as visit_date,
       coalesce(piz.name, '-') as pizzeria_name
from (select *
      from person_visits
      where visit_date between '2022-01-01' and '2022-01-03') pv
         full join pizzeria piz on piz.id = pv.pizzeria_id
         full join person per on pv.person_id = per.id
order by person_name, visit_date, pizzeria_name