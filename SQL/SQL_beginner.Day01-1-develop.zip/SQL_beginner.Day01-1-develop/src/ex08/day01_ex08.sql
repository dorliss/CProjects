select po.order_date, concat(pers.name, ' (age:', pers.age, ')') as person_information
from person_order po
natural join (select pers.id as person_id, pers.name, pers.age from person pers) pers
order by po.order_date, person_information