select pers.name as person_name,
       m.pizza_name,
       piz.name as pizzeria_name
from person pers
inner join person_order po
    on pers.id = po.person_id
inner join menu m
    on po.menu_id = m.id
inner join pizzeria piz
    on m.pizzeria_id = piz.id
order by person_name, pizza_name, pizzeria_name