select po.order_date, concat(pers.name, ' (age:', pers.age, ')') as person_information
from person_order po inner join person pers on po.person_id = pers.id
order by po.order_date, person_information
