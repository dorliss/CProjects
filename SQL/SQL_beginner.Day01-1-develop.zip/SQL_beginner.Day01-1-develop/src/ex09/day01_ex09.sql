--  with in
select name
from pizzeria piz
where piz.id not in (select pizzeria_id from person_visits)

-- with exist
select name
from pizzeria piz
where not exists (select pizzeria_id from person_visits pv where pv.pizzeria_id = piz.id)