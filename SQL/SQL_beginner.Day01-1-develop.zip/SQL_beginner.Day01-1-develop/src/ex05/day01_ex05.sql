select pers.id as "person.id", 
	   pers.name as "person.name", 
	   pers.age, pers.gender, pers.address,
       piz.id as "pizzeria.id", 
	   piz.name as "pizzeria.name", rating
from person pers, pizzeria piz
order by pers.id, piz.id