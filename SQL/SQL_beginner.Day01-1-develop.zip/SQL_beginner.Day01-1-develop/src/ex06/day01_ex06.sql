select po.order_date as action_date, (select pers.name from person pers where pers.id = po.person_id) as person_name
from person_order po
intersect
select pv.visit_date, (select pers.name from person pers where pers.id = pv.person_id) as person_name
from person_visits pv
order by action_date asc, person_name desc
