set enable_seqscan = off;

explain analyze
select mn.pizza_name, piz.name as pizzeria_name
FROM menu mn
JOIN pizzeria piz
    ON mn.pizzeria_id = piz.id
