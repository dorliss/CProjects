create index idx_person_name on person(upper(name));

set enable_seqscan = off;
explain analyze
select *
from person pers
where upper(pers.name) = 'KATE'