# DO5_SimpleDocker Отчётик

## Часть 1

01. `docker pull nginx`  
![pull_nginx](other/part1/1.png)

02. `docker images`  
![images](other/part1/2.png)

03. `docker run -d --name nginxer nginx`  
![run_nginx](other/part1/3.png)

04. `docker ps` (ps - Process Status(Состояние процесса))  
![ps](other/part1/4.png)

05. Информация о контейнере `ngnix`:

    01. IP = 172.17.0.2 (`docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' nginxer`)  
    ![nginx_ip](other/part1/5.png)

    02. Размер = 1095 байт (`docker inspect --size -f 'RW = {{ .SizeRw }}; ROOTFS = {{ .SizeRootFs }}' nginxer`)  
    ![nginx_ip](other/part1/6.png)  
    Кроме того, `docker ps -s`:  
    ![docker_ps_s](other/part1/7.png)

    03. Список подключенных портов (`docker inspect --type=container -f '{{.NetworkSettings.Ports}}' nginxer`)  
    ![nginx_mapped_ports](other/part1/8.png)

06. `docker stop`  
![stop](other/part1/9.png)

07. `docker ps` после остановки контейнера  
![ps_after_stop](other/part1/10.png)

08. `docker run -d -p 80:80 -p 443:443 --name nginx2 nginx`  
![with_ports](other/part1/11.png)

09. `docker ps`  
![nginxer2](other/part1/12.png)

10. Nginx работает на порту 80  
![nginx_80](other/part1/13.png)

11. Nginx перезапущен и также работает, но название изменилось  
![restarted](other/part1/14.png)

## Часть 2

1. `docker exec nginx2 cat /etc/nginx/nginx.conf`.  
![origin_nginx_conf](other/part2/1.png)

2. Копируем базовый конфигурационный файл, вставляем его в локальный конфигурационный файл и затем дополняем его конфигурацией [локального] сервера. 
![new_nginx_conf](other/part2/2.png)

3. Перезагрузка (`docker exec nginx2 nginx -s reload`) и проверка **localhost:80/status** (`curl localhost:80/status`):  
![new_nginx_results](other/part2/3.png)

4. EЭкспорт контейнера в **.tar** архив (`docker export nginx2 > nginx2.tar`)  
![container.tar](other/part2/4.png)

5. Остановка контейнеров, удаление изображений и самих контейнеров - процедура очистки.
![stop_and_remove](other/part2/5.png)

6. Импортируем с помощью `docker import -c 'CMD ["nginx", "-g", "daemon off;"]' ./nginx2.tar re_nginx` и запускаем через `docker run --rm -d -p 80:80 -p 443:443 --name nginxer3 re_nginx`:
![import_relaunch](other/part2/6.png)

Файлы **nginx.conf** находится в `other/part2`

## Часть 3

0. Часть состоит в том, чтобы написать мини-сервер "Привет, мир!" на C с использованием модуля FastCGI.

1. Очистка.  
![cleaning](other/part3/1.png)

2. `docker pull nginx` - нужно повторить, потому что я его удалила.

3. Запускаем контейнер nginx (`docker run --rm -d -p 81:81 --name server nginx`) затем выполняем следующие команд:

    1. `docker exec server apt update` - проверка системы на наличие обновлений;

    2. `docker exec server apt upgrade -y` обновление контейнера;

    3. `docker exec server apt install -y gcc spawn-fcgi libfcgi-dev` - инструменты для компиляции сервера FastCGI;

    4. фиксируем изменения: `docker commit $CONTAINER_ID [new_image]`  
    ![commited](other/part3/2.png)

    5. копирование файлов из каталога **part3**:

        1. `docker cp nginx.conf server:/etc/nginx/`;

        2. `docker cp fastcgi_server.c server:/`

    6. `docker exec server gcc ./fastcgi_server.c -l fcgi -o fcgi_server` - компиляция сервера FastCGI.

    7. `docker exec server spawn-fcgi -p 8080 fcgi_server` - запуск;

    8. `docker exec server nginx -s reload` - новая конфигурация nginx (перезагрузка);

4. Локальный запуск `curl http://localhost:81/`, чтобы проверить "жизнедеятельность" сервера
![fcgi_alive](other/part3/3.png)

Файлы **nginx.conf** и **fastcgi_server.c** находятся в `other/part3`.

## Часть 4

1. **Часть 4** cсодержит необходимые файлы для сборки контейнера.

2. `docker build . -t server:v2` - создание образа;

3. `docker images` - проверяем, что сборка выполнена успешно;

4. запускаем `docker run --rm -d -p 80:81 --name server2 server:v2` экземпляр;

5. `curl localhost:80` -> "Hello World!", 
   `curl localhost:80/status` -> состояние nginx.

Результат:  
![dockefile_server](other/part4/1.png)

Файлы **Dockerfile**, **fastcgi_server.c**, **start_server.sh**, **nginx.conf** находятся в `other/part4`.

## Часть 5

0. Скачать доклю для **Часть 5** нужно ввести сначала `curl -L -o dockle.deb https://github.com/goodwithtech/dockle/releases/v0.4.14/dockle_0.4.14_Linux-64bit.deb`, а затем `sudo dpkg -i dockle.deb && rm dockle.deb`

1. `dockle [YOUR_IMAGE_NAME]` - Вылезают куча проблем;

2. 3яя версия серверного контейнера:

    0. Остановка и очистка (`docker system prune -a`);

    1. Вводим команду для включения доверия к контенту Docker: `export DOCKER_CONTENT_TRUST=1`;

    2. `docker build . -t server:v3`;

    3. `dockle -ak NGINX_GPGKEY -ak NGINX_GPGKEY_PATH server:v3`;

    4. Вводим команду: `export DOCKER_CONTENT_TRUST=0` (без нее следующая комада дасть ошибку **docker: you are not outhorised to perform this operation: server returned 401**);

    5. `docker run --rm -it -d -p 80:81 --name server3 server:v3` (Флаг **-it** в команде **docker run** используется для создания интерактивного контейнера, который позволяет взаимодействовать с ним через терминал);

    6. `curl localhost:80` -> Hello, Horld!;

    7. `curl localhost:80/status` - Состояние nginx;

Results:  
![dockled_results](other/part5/1.png)

Файлы **Dockerfile**, **fastcgi_server.c**, **start_server.sh**, **nginx.conf** находятся в `other/part5`.

## Часть 6

0. Написать файл docker-compose.yml, с помощью которого поднимается докер контейнер из **Части 5** и докер контейнер с nginx, который будет проксировать все запросы с 8080 порта на 81 порт первого контейнера

1. Вводим команды: `docker-compose build` и `docker-compose up -d`

Результат:  
![composed_results](other/part6/1.png)

Файлы **Dockerfile**, **fastcgi_server.c**, **start_server.sh**, **nginx.conf**, **docker-compose.yml** находятся в `other/part6`.

Конец)
