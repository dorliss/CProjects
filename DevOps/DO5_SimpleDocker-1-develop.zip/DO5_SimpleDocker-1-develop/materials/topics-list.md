Hello, student of School21!😉

To make it easier for you to navigate the material, we have prepared a list of topics that you will learn in this project.

We will study:

- docker commands;
- using docker images;
- creating docker images;
- nginx;
- creating web-server with FastCgi;
- dockle;
- docker-compose.

Now, knowing what awaits you in this project, you can slowly begin to study the topics listed above.😇