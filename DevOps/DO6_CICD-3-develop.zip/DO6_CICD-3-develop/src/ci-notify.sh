#!/bin/bash

# Токен бота Telegram
BOT_TOKEN="7287766242:AAFpLTfrv-J7wfpnn2MMXyl8bc5Q2sb6sk8"

# ID чата, в который будут отправляться сообщения
CHAT_ID="843076482"

TIME="10"
URL="https://api.telegram.org/bot$BOT_TOKEN/sendMessage"

# Формирование текста сообщения
TEXT='DO6_CICD-3
URL: '"$CI_PROJECT_URL"'
Branch: '"$CI_COMMIT_REF_NAME"'
Commit: '"$CI_COMMIT_SHORT_SHA"'
Stage: '"$CI_JOB_STAGE"', Status: '"$CI_JOB_STATUS"' '"$var_status"'%0A------------------'

# Отправка сообщения в Telegram
curl -s --max-time $TIME -d "chat_id=$CHAT_ID&disable_web_page_preview=1&text=$TEXT" $URL &>/dev/null
