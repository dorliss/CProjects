#!/bin/bash

total_identical=0
total_differ=0

./s21_cat s21_cat.c >> s21_cat.txt
cat s21_cat.c >> cat.txt
diff -s s21_cat.txt cat.txt
identical=$(echo "$?" | grep -c "0")
differ=$(echo "$?" | grep -c "1")
total_identical=$((total_identical + identical))
total_differ=$((total_differ + differ))
rm s21_cat.txt cat.txt

./s21_cat -b s21_cat.c >> s21_cat.txt
cat -b s21_cat.c >> cat.txt
diff -s s21_cat.txt cat.txt
identical=$(echo "$?" | grep -c "0")
differ=$(echo "$?" | grep -c "1")
total_identical=$((total_identical + identical))
total_differ=$((total_differ + differ))
rm s21_cat.txt cat.txt

./s21_cat -e s21_cat.c >> s21_cat.txt
cat -e s21_cat.c >> cat.txt
diff -s s21_cat.txt cat.txt
identical=$(echo "$?" | grep -c "0")
differ=$(echo "$?" | grep -c "1")
total_identical=$((total_identical + identical))
total_differ=$((total_differ + differ))
rm s21_cat.txt cat.txt

./s21_cat -n s21_cat.c >> s21_cat.txt
cat -n s21_cat.c >> cat.txt
diff -s s21_cat.txt cat.txt
identical=$(echo "$?" | grep -c "0")
differ=$(echo "$?" | grep -c "1")
total_identical=$((total_identical + identical))
total_differ=$((total_differ + differ))
rm s21_cat.txt cat.txt

./s21_cat -s s21_cat.c >> s21_cat.txt
cat -s s21_cat.c >> cat.txt
diff -s s21_cat.txt cat.txt
identical=$(echo "$?" | grep -c "0")
differ=$(echo "$?" | grep -c "1")
total_identical=$((total_identical + identical))
total_differ=$((total_differ + differ))
rm s21_cat.txt cat.txt

./s21_cat -t s21_cat.c >> s21_cat.txt
cat -t s21_cat.c >> cat.txt
diff -s s21_cat.txt cat.txt
identical=$(echo "$?" | grep -c "0")
differ=$(echo "$?" | grep -c "1")
total_identical=$((total_identical + identical))
total_differ=$((total_differ + differ))
rm s21_cat.txt cat.txt

echo "SUCCESS: $total_identical"
echo "FAIL: $total_differ"
