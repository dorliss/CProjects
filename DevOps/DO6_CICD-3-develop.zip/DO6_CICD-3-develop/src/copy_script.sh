#!/bin/bash

# Настройки для второй виртуальной машины
REMOTE_HOST="192.168.56.102"
REMOTE_USER="dorlis"
REMOTE_DIR="/usr/local/bin"

#!/bin/bash

# Предоставляем права пользователю gitlab-runner
chown -R gitlab-runner:gitlab-runner artifacts/
chmod -R 755 artifacts/

# Выполняем основные команды
scp -r artifacts/s21_cat ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_DIR}
scp -r artifacts/s21_grep ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_DIR}

# Устанавливаем права на файлы на удаленном хосте
ssh ${REMOTE_USER}@${REMOTE_HOST} "
  sudo chmod +x ${REMOTE_DIR}/s21_cat
  sudo chmod +x ${REMOTE_DIR}/s21_grep
"

echo "Deployment completed successfully!"
