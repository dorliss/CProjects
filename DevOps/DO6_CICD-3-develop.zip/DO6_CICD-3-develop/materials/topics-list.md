Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will learn:

- bash scripts;
- copying files over ssh tunnel;
- gitlab runner;
- CI/CD.

Now that you know what to expect in this project, you can slowly start studying the topics listed above. 😇