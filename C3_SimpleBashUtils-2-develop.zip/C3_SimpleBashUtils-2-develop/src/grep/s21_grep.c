#include "s21_grep.h"

int main(int argc, char** argv) {
  int flag = 0;
  Options options = {0};
  char* short_options = "e:ivclnhsf:o";
  if (argc < 2) {
    printf("No such file or directory\n");
    flag = 1;
  } else {
    int err = parsing(argc, argv, short_options, &options);
    if (err == 0) {
      int mult = optind;

      for (; mult < argc; mult++) {
        output_grep_result(argv[mult], &options);
      }
    }
  }
  free(options.pattern);
  return flag;
}

int parsing(int argc, char* argv[], char* short_options, Options* options) {
  char current_option;
  int error = 0;
  while ((current_option =
              getopt_long(argc, argv, short_options, NULL, NULL)) != -1) {
    switch (current_option) {
      case 'e':
        options->e = 1;
        pattern_add(options, optarg);
        break;
      case 'i':
        options->i = REG_ICASE;
        break;
      case 'v':
        options->v = 1;
        break;
      case 'c':
        options->c = 1;
        break;
      case 's':
        options->s = 1;
        break;
      case 'l':
        options->l = 1;
        break;
      case 'n':
        options->n = 1;
        break;
      case 'h':
        options->h = 1;
        break;
      case 'f':
        options->f = 1;
        add_reg_from_file(options, optarg);
        break;
      case 'o':
        options->o = 1;
        break;
      default:
        error = 1;
        break;
    }
  }
  if (options->len_pattern == 0) {
    pattern_add(options, argv[optind]);
    optind++;
  }
  if (options->v || options->c || options->l) options->o = 0;
  if (argc - optind == 1) options->h = 1;
  return error;
}

void output_grep_result(char* argv, Options* options) {
  FILE* fp = fopen(argv, "r");
  regex_t re;
  int error = regcomp(&re, options->pattern, REG_EXTENDED | options->i);
  if (error) perror("Error");
  if (fp != NULL) {
    char* line = NULL;
    size_t memlen = 0;
    int read = 0;
    int line_count = 1;
    int count = 0;
    read = getline(&line, &memlen, fp);
    while (read != -1) {
      int result = regexec(&re, line, 0, NULL, 0);
      if ((result == 0 && !options->v) || (options->v && result != 0)) {
        if (!options->c && !options->l) {
          if (options->h != 1) printf("%s:", argv);
          if (options->n) printf("%d:", line_count);
          if (options->o) {
            print_match(&re, line);
          } else
            output_line(line, read);
        }
        count++;
      }
      if (error != 0) pattern_add(options, line);
      read = getline(&line, &memlen, fp);
      line_count++;
    }
    free(line);
    if (options->c) {
      if (!options->h) {
        printf("%s:", argv);
      }
      if (options->l && count > 0) count = 1;
      printf("%d\n", count);
    }
    if (options->l && count > 0) printf("%s\n", argv);

    fclose(fp);
  } else if (options->s != 1)
    printf("Error not file");
  regfree(&re);
}

void output_line(char* line, int read) {
  for (int i = 0; i < read; i++) {
    putchar(line[i]);
  }
  if (line[read - 1] != '\n') putchar('\n');
}

void pattern_add(Options* options, char* pattern) {
  int n = strlen(pattern);
  if (options->len_pattern == 0) {
    options->pattern = malloc(1024 * sizeof(char));
    options->pattern[0] = '\0';
    options->mem_pattern = 1024;
  }
  if (options->mem_pattern < options->len_pattern + n) {
    options->pattern = realloc(options->pattern, options->mem_pattern * 2);
  }
  if (options->len_pattern != 0) {
    strcat(options->pattern + options->len_pattern, "|");
    options->len_pattern++;
  }
  options->len_pattern +=
      sprintf(options->pattern + options->len_pattern, "(%s)", pattern);
}

void add_reg_from_file(Options* options, char* argv) {
  FILE* fp = fopen(argv, "r");
  if (fp != NULL) {
    char* line = NULL;
    size_t memlen = 0;
    int read = 0;
    read = getline(&line, &memlen, fp);
    while (read != -1) {
      if (line[read - 1] == '\n') line[read - 1] = '\0';
      pattern_add(options, line);
      read = getline(&line, &memlen, fp);
    }
    free(line);
    fclose(fp);
  } else if (options->s != 1)
    printf("Error not file");
}

void print_match(regex_t* re, char* line) {
  regmatch_t match;
  int offset = 0;
  while (1) {
    int result = regexec(re, line + offset, 1, &match, 0);
    if (result != 0) {
      break;
    }
    for (int i = match.rm_so; i < match.rm_eo; i++) {
      putchar(line[i]);
    }
    putchar('\n');
    offset += match.rm_eo;
  }
}