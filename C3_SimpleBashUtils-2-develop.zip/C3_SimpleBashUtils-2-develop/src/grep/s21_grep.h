#ifndef GREP_H
#define GREP_H
#define _GNU_SOURCE

#include <getopt.h>
#include <regex.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Options {
  int e, i, v, c, l, n, h, s, f, o;
  char* pattern;

  int len_pattern;
  int mem_pattern;
} Options;

int parsing(int argc, char* argv[], char* short_options, Options* options);
void output_grep_result(char* argv, Options* options);
void output_line(char* line, int read);
void pattern_add(Options* options, char* pattern);
void add_reg_from_file(Options* options, char* argv);
void print_match(regex_t* re, char* line);

#endif