#ifndef S21_CAT_H
#define S21_CAT_H
#define _GNU_SOURCE

#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct Options {
  int b, e, n, s, t, v;
} Options;

struct option long_options[] = {{"number-nonblank", no_argument, NULL, 'b'},
                                {"number", no_argument, NULL, 'n'},
                                {"squeeze-blank", no_argument, NULL, 's'},
                                {0, 0, 0, 0}};

int parsing(int argc, char *argv[], char *short_options,
            struct option long_options[], Options *options);
char option_v(char c);
void print_file(char *argv, Options *options);

#endif

// -e предполагает и -v (GNU only: -E то же самое, но без применения -v) | также
// отображает символы конца строки как $  | -b (GNU: --number-nonblank) |
// нумерует только непустые строки | -n (GNU: --number) | нумерует все выходные
// строки | -s (GNU: --squeeze-blank) | сжимает несколько смежных пустых строк |
// -t предполагает и -v (GNU: -T то же самое, но без применения -v) | также
// отображает табы как ^I |