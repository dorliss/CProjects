#include "s21_cat.h"

int main(int argc, char *argv[]) {
  Options options = {0};
  int flag = 0;
  char *short_options = "+beEnstTv";
  if (argc == 1) {
    printf("No such file or directory\n");
    flag = 1;
  } else {
    int err = parsing(argc, argv, short_options, long_options, &options);
    if (err == 0) {
      int mult = optind;

      for (; mult < argc; mult++) {
        print_file(argv[mult], &options);
      }
    }
  }
  return flag;
}

int parsing(int argc, char *argv[], char *short_options,
            struct option long_options[], Options *options) {
  int long_options_index = 0;

  char current_option;
  int error = 0;
  while ((current_option = getopt_long(argc, argv, short_options, long_options,
                                       &long_options_index)) != -1) {
    switch (current_option) {
      case 'b':
        options->b = 1;
        break;
      case 'e':
        options->v = 1;
        options->e = 1;
        break;
      case 'E':
        options->e = 1;
        break;
      case 'n':
        options->n = 1;
        break;
      case 's':
        options->s = 1;
        break;
      case 't':
        options->v = 1;
        options->t = 1;
        break;
      case 'T':
        options->t = 1;
        break;
      case 'v':
        options->v = 1;
        break;
      default:
        error = 1;
        break;
    }
  }
  return error;
}

char option_v(char c) {
  if ((c >= 0 && c < 32) && c != '\n' && c != '\t') {
    printf("^");
    c += 64;
  } else if (c == 127) {
    printf("^");
    c = '?';
  }

  return c;
}

void print_file(char *argv, Options *options) {
  FILE *fp = fopen(argv, "r");
  char c = '\0';
  int count = 1;
  int count_s = 0;
  if (fp != NULL) {
    for (char prev = '\n'; !feof(fp); prev = c) {
      c = getc(fp);
      if (c != EOF) {
        if (options->s == 1 && prev == '\n' && c == '\n') {
          count_s++;
          if (count_s > 1) {
            continue;
          }
        } else {
          count_s = 0;
        }
        if (options->b == 1 && options->n == 1 && prev == '\n' && c != '\n') {
          printf("%6d\t", count);
          count++;
        }
        if (options->n == 1 && options->b != 1 && prev == '\n') {
          printf("%6d\t", count);
          count++;
        }
        if (options->b == 1 && options->n != 1 && prev == '\n' && c != '\n') {
          printf("%6d\t", count);
          count++;
        }
        if (options->e == 1 && c == '\n') {
          if (options->b == 1 && c == '\n' && prev == '\n') {
            printf("      \t$");
          } else {
            printf("$");
          }
        }
        if (options->t == 1 && c == '\t') {
          printf("^I");
          continue;
        }
        if (options->v == 1) {
          c = option_v(c);
        }
        printf("%c", c);
      }
    }
    fclose(fp);
  } else {
    printf("Error not file");
  }
}