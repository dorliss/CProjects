#include "s21_decimal.h"

int s21_is_less(s21_decimal first, s21_decimal second) {
  int res = -1;
  char d_flag = 'l';
  int first_sign = get_sign(first);
  int second_sign = get_sign(second);

  if (first_sign == 0 && second_sign == 0)
    res = dec_comparison(first, second, d_flag);
  else if (first_sign == 1 && second_sign == 1)
    res = dec_comparison(first, second, d_flag);
  else if (first_sign == 1 && second_sign == 0)
    res = 1;
  else if (first_sign == 0 && second_sign == 1)
    res = 0;
  return res;
}

int s21_is_less_or_equal(s21_decimal first, s21_decimal second) {
  return (s21_is_less(first, second) || s21_is_equal(first, second));
}

int s21_is_greater(s21_decimal first, s21_decimal second) {
  int res = -1;
  char d_flag = 'g';
  int first_sign = get_sign(first);
  int second_sign = get_sign(second);

  if (first_sign == 0 && second_sign == 0)
    res = dec_comparison(first, second, d_flag);
  else if (first_sign == 1 && second_sign == 1)
    res = dec_comparison(first, second, d_flag);
  else if (first_sign == 1 && second_sign == 0)
    res = 0;
  else if (first_sign == 0 && second_sign == 1)
    res = 1;
  return res;
}

int s21_is_greater_or_equal(s21_decimal first, s21_decimal second) {
  return (s21_is_greater(first, second) || s21_is_equal(first, second));
}

int s21_is_equal(s21_decimal first, s21_decimal second) {
  int res = -1;
  char d_flag = 'e';
  int first_sign = get_sign(first);
  int second_sign = get_sign(second);

  if (first_sign == 0 && second_sign == 0)
    res = dec_comparison(first, second, d_flag);
  else if (first_sign == 1 && second_sign == 1)
    res = dec_comparison(first, second, d_flag);
  else if (first_sign == 1 && second_sign == 0)
    res = 0;
  else if (first_sign == 0 && second_sign == 1)
    res = 0;
  return res;
}

int s21_is_not_equal(s21_decimal first, s21_decimal second) {
  return !s21_is_equal(first, second);
}

int dec_comparison(s21_decimal first, s21_decimal second, char d_flag) {
  int res = -1;
  int inverted = 0;
  int match = 0;

  scale_equalize(&first, &second);
  if (get_sign(first) == 1) {
    invert_bit(&(first.bits[3]), 31);
    invert_bit(&(second.bits[3]), 31);
    inverted = 1;
  }
  for (int i = 3; i > -1; i--) {
    if (first.bits[i] != second.bits[i]) {
      if (first.bits[i] > second.bits[i] && d_flag == 'g') {
        res = 1;
        break;
      } else if (first.bits[i] < second.bits[i] && d_flag == 'l') {
        res = 1;
        break;
      } else {
        res = 0;
        break;
      }
    } else
      match++;
  }
  if (match == 4 && d_flag == 'e') res = 1;
  if (is_zero(first) == 1 && is_zero(second) == 1) {
    if (d_flag == 'e') res = 1;
    if (d_flag == 'g' || d_flag == 'l') res = 0;
    if (d_flag == 'e' &&
        (get_bit(first, 127) == 1 || get_bit(second, 127) == 1))
      res = 1;
  }
  if (inverted == 1 && d_flag != 'e') invert_bit((unsigned int*)&res, 0);
  return res;
}
